// Admin Dashboard Logic 💖

class AdminDashboard {
    constructor() {
        this.userSession = this.getUserSession();
        this.allDocuments = [];
        this.clients = [];
        this.processingQueue = [];
        this.currentFilter = 'review';
        
        if (!this.userSession || this.userSession.role !== 'admin') {
            window.location.href = 'index.html';
            return;
        }
        
        this.initializeDashboard();
        this.loadData();
    }
    
    getUserSession() {
        const session = localStorage.getItem('userSession');
        return session ? JSON.parse(session) : null;
    }
    
    initializeDashboard() {
        // Set welcome message
        document.getElementById('adminWelcome').textContent = `Welcome, ${this.userSession.name}!`;
        
        // Initialize event listeners
        this.initializeEventListeners();
        
        // Load initial data
        this.generateSampleData();
        this.updateStats();
        this.renderProcessingQueue();
        this.renderClients();
        this.renderDocuments();
    }
    
    initializeEventListeners() {
        // Refresh button
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.refreshData();
        });
        
        // Email button
        document.getElementById('emailBtn').addEventListener('click', () => {
            this.showEmailPanel();
        });
        
        // Queue filter buttons
        document.querySelectorAll('.queue-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterQueue(e.target.dataset.filter);
            });
        });
        
        // Document browser tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterDocuments(e.target.dataset.folder);
            });
        });
        
        // Email form
        document.getElementById('emailForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendEmail();
        });
    }
    
    generateSampleData() {
        // Load real registered users
        this.clients = this.loadRealClients();
        
        // Generate processing queue from real documents that need review
        this.processingQueue = this.generateProcessingQueue();
        
        // Load client documents from localStorage
        this.loadClientDocuments();
    }
    
    generateProcessingQueue() {
        const queue = [];
        
        // Find documents that need review from all clients
        this.clients.forEach(client => {
            const clientDocs = JSON.parse(localStorage.getItem(`documents_${client.email}`) || '[]');
            
            clientDocs.forEach(doc => {
                if (['review', 'error'].includes(doc.status)) {
                    let type = 'review';
                    let issue = 'Document requires manual review';
                    let priority = 'medium';
                    
                    if (doc.details && doc.details.includes('password')) {
                        type = 'password';
                        issue = 'Document is password-protected and cannot be processed';
                        priority = 'high';
                    } else if (doc.status === 'error') {
                        type = 'error';
                        issue = 'Processing failed - document may be corrupted';
                        priority = 'high';
                    }
                    
                    queue.push({
                        id: `q_${doc.id}`,
                        filename: doc.filename,
                        clientEmail: client.email,
                        clientName: client.name,
                        type: type,
                        priority: priority,
                        uploadTime: new Date(doc.uploadTime).toLocaleString(),
                        issue: issue,
                        action: type === 'password' ? 'Email client for resubmission' : 'Manual review required'
                    });
                }
            });
        });
        
        return queue;
    }
    
    loadRealClients() {
        // Get all registered users from login system
        const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '{}');
        const defaultUsers = {
            'client@demo.com': { password: 'demo123', role: 'client', name: 'Demo Client' },
            'john@client.com': { password: 'client123', role: 'client', name: 'John Smith' }
        };
        
        const allUsers = { ...defaultUsers, ...registeredUsers };
        const clients = [];
        
        Object.keys(allUsers).forEach((email, index) => {
            const user = allUsers[email];
            if (user.role === 'client') {
                // Count documents for this client
                const clientDocs = JSON.parse(localStorage.getItem(`documents_${email}`) || '[]');
                
                clients.push({
                    id: index + 1,
                    name: user.name,
                    email: email,
                    status: 'active',
                    documents: clientDocs.length,
                    lastActivity: clientDocs.length > 0 ? 
                        new Date(Math.max(...clientDocs.map(d => new Date(d.uploadTime)))).toISOString().split('T')[0] :
                        new Date().toISOString().split('T')[0]
                });
            }
        });
        
        return clients;
    }
    
    loadClientDocuments() {
        this.allDocuments = [];
        
        this.clients.forEach(client => {
            const clientDocs = localStorage.getItem(`documents_${client.email}`);
            if (clientDocs) {
                const docs = JSON.parse(clientDocs);
                docs.forEach(doc => {
                    doc.clientName = client.name;
                    doc.clientEmail = client.email;
                });
                this.allDocuments.push(...docs);
            }
        });
    }
    
    loadData() {
        this.loadClientDocuments();
        this.updateStats();
        this.renderProcessingQueue();
        this.renderClients();
        this.renderDocuments();
    }
    
    refreshData() {
        // Show loading state
        const refreshBtn = document.getElementById('refreshBtn');
        const originalText = refreshBtn.textContent;
        refreshBtn.textContent = '🔄 Refreshing...';
        refreshBtn.disabled = true;
        
        // Reload all data from localStorage
        setTimeout(() => {
            this.clients = this.loadRealClients();
            this.processingQueue = this.generateProcessingQueue();
            this.loadData();
            refreshBtn.textContent = originalText;
            refreshBtn.disabled = false;
            
            // Show success notification
            this.showNotification('success', 'Data refreshed successfully!');
        }, 1000);
    }
    
    updateStats() {
        const totalDocs = this.allDocuments.length;
        const processedDocs = this.allDocuments.filter(doc => doc.status === 'completed').length;
        const reviewDocs = this.allDocuments.filter(doc => ['review', 'error'].includes(doc.status)).length + this.processingQueue.length;
        const activeClients = this.clients.filter(client => client.status === 'active').length;
        
        document.getElementById('totalDocuments').textContent = totalDocs;
        document.getElementById('processedDocs').textContent = processedDocs;
        document.getElementById('reviewDocs').textContent = reviewDocs;
        document.getElementById('activeClients').textContent = activeClients;
    }
    
    filterQueue(filter) {
        this.currentFilter = filter;
        
        // Update active button
        document.querySelectorAll('.queue-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.filter === filter);
        });
        
        this.renderProcessingQueue();
    }
    
    renderProcessingQueue() {
        const grid = document.getElementById('queueGrid');
        let filteredQueue = this.processingQueue;
        
        if (this.currentFilter !== 'all') {
            filteredQueue = this.processingQueue.filter(item => item.type === this.currentFilter);
        }
        
        if (filteredQueue.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">✅</div>
                    <h3>No items in queue</h3>
                    <p>All documents are processed!</p>
                </div>
            `;
            return;
        }
        
        grid.innerHTML = filteredQueue.map(item => this.createQueueCard(item)).join('');
    }
    
    createQueueCard(item) {
        const typeLabels = {
            'password': 'Password Protected',
            'review': 'Manual Review',
            'error': 'Processing Error'
        };
        
        return `
            <div class="queue-item ${item.type}">
                <div class="queue-header">
                    <div class="queue-title">${item.filename}</div>
                    <div class="queue-priority priority-${item.priority}">${item.priority.toUpperCase()}</div>
                </div>
                <div class="queue-details">
                    <strong>Client:</strong> ${item.clientName} (${item.clientEmail})<br>
                    <strong>Type:</strong> ${typeLabels[item.type]}<br>
                    <strong>Uploaded:</strong> ${item.uploadTime}<br>
                    <strong>Issue:</strong> ${item.issue}
                </div>
                <div class="queue-actions">
                    <button class="queue-action-btn primary" onclick="adminDashboard.emailClient('${item.clientEmail}', '${item.type}', '${item.filename}')">
                        📧 Email Client
                    </button>
                    <button class="queue-action-btn" onclick="adminDashboard.resolveItem('${item.id}')">
                        ✅ Resolve
                    </button>
                    <button class="queue-action-btn" onclick="adminDashboard.viewDetails('${item.id}')">
                        👁️ Details
                    </button>
                </div>
            </div>
        `;
    }
    
    renderClients() {
        const table = document.getElementById('clientsTable');
        
        table.innerHTML = `
            <div class="table-header">
                <div>Name</div>
                <div>Email</div>
                <div>Documents</div>
                <div>Status</div>
                <div>Actions</div>
            </div>
            ${this.clients.map(client => `
                <div class="table-row">
                    <div>${client.name}</div>
                    <div>${client.email}</div>
                    <div>${client.documents}</div>
                    <div><span class="client-status status-${client.status}">${client.status}</span></div>
                    <div>
                        <button class="queue-action-btn" onclick="adminDashboard.emailClient('${client.email}')">📧</button>
                        <button class="queue-action-btn" onclick="adminDashboard.viewClientDocs('${client.email}')">📁</button>
                    </div>
                </div>
            `).join('')}
        `;
    }
    
    renderDocuments() {
        const grid = document.getElementById('documentGrid');
        
        if (this.allDocuments.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📄</div>
                    <h3>No documents found</h3>
                    <p>Documents will appear here as clients upload them</p>
                </div>
            `;
            return;
        }
        
        grid.innerHTML = this.allDocuments.map(doc => this.createDocumentCard(doc)).join('');
    }
    
    createDocumentCard(doc) {
        const icons = {
            'RDL': '📋',
            'RCS': '📝',
            'processing': '⏳',
            'completed': '✅',
            'review': '⚠️',
            'error': '❌'
        };
        
        return `
            <div class="document-card ${doc.status}">
                <div class="doc-icon">${icons[doc.status] || '📄'}</div>
                <div class="doc-name">${doc.processedName || doc.filename}</div>
                <div class="doc-details">
                    <strong>Client:</strong> ${doc.clientName}<br>
                    <strong>Original:</strong> ${doc.filename}<br>
                    <strong>Size:</strong> ${doc.size}<br>
                    <strong>Uploaded:</strong> ${new Date(doc.uploadTime).toLocaleString()}<br>
                    <strong>Status:</strong> ${doc.details}
                </div>
                <div class="doc-actions">
                    <button class="action-btn" onclick="adminDashboard.downloadDocument('${doc.id}')">Download</button>
                    <button class="action-btn" onclick="adminDashboard.emailClient('${doc.clientEmail}')">Email Client</button>
                </div>
            </div>
        `;
    }
    
    emailClient(clientEmail, type = 'general', filename = '') {
        const emailPanel = document.getElementById('emailPanel');
        const recipientField = document.getElementById('recipientEmail');
        const subjectField = document.getElementById('emailSubject');
        const messageField = document.getElementById('emailMessage');
        
        // Pre-fill email based on type
        recipientField.value = clientEmail;
        
        if (type === 'password') {
            subjectField.value = 'Document Resubmission Required - Password Protection Detected';
            messageField.value = `Dear Client,\n\nYour document "${filename}" could not be processed because it is password-protected.\n\nPlease resubmit your document without password protection to continue processing.\n\nIf you have questions, please contact our support team.\n\nThank you,\nDocument Quality Team`;
        } else if (type === 'error') {
            subjectField.value = 'Document Processing Issue';
            messageField.value = `Dear Client,\n\nWe encountered an issue processing your document "${filename}".\n\nPlease resubmit your document or contact our support team for assistance.\n\nThank you,\nDocument Quality Team`;
        } else {
            subjectField.value = 'Document Processing Update';
            messageField.value = 'Dear Client,\n\nWe wanted to provide you with an update regarding your document processing.\n\nThank you,\nDocument Quality Team';
        }
        
        emailPanel.style.display = 'flex';
    }
    
    sendEmail() {
        const recipient = document.getElementById('recipientEmail').value;
        const subject = document.getElementById('emailSubject').value;
        const message = document.getElementById('emailMessage').value;
        
        // Simulate sending email
        console.log('📧 Sending email:', { recipient, subject, message });
        
        // Show success notification
        this.showNotification('success', `Email sent to ${recipient}!`);
        
        // Close email panel
        this.closeEmailPanel();
        
        // Log email activity
        this.logEmailActivity(recipient, subject);
    }
    
    closeEmailPanel() {
        document.getElementById('emailPanel').style.display = 'none';
    }
    
    resolveItem(itemId) {
        this.processingQueue = this.processingQueue.filter(item => item.id !== itemId);
        this.renderProcessingQueue();
        this.updateStats();
        this.showNotification('success', 'Item resolved successfully!');
    }
    
    viewDetails(itemId) {
        const item = this.processingQueue.find(i => i.id === itemId);
        if (item) {
            alert(`Queue Item Details:\n\nFilename: ${item.filename}\nClient: ${item.clientName}\nIssue: ${item.issue}\nAction: ${item.action}\nUploaded: ${item.uploadTime}`);
        }
    }
    
    viewClientDocs(clientEmail) {
        const client = this.clients.find(c => c.email === clientEmail);
        const clientDocs = this.allDocuments.filter(doc => doc.clientEmail === clientEmail);
        
        alert(`${client.name}'s Documents:\n\nTotal: ${clientDocs.length}\nProcessed: ${clientDocs.filter(d => d.status === 'completed').length}\nPending: ${clientDocs.filter(d => d.status !== 'completed').length}`);
    }
    
    downloadDocument(docId) {
        alert('Download functionality coming soon!');
    }
    
    showNotification(type, message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#00b894' : '#e74c3c'};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 1001;
            animation: slideInRight 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    logEmailActivity(recipient, subject) {
        const activity = {
            timestamp: new Date().toISOString(),
            recipient: recipient,
            subject: subject,
            sender: this.userSession.email
        };
        
        // Store in localStorage for demo
        const activities = JSON.parse(localStorage.getItem('emailActivities') || '[]');
        activities.unshift(activity);
        localStorage.setItem('emailActivities', JSON.stringify(activities.slice(0, 50))); // Keep last 50
    }
    
    filterDocuments(folder) {
        // Update active tab
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.folder === folder);
        });
        
        // Filter and render documents
        let filteredDocs = this.allDocuments;
        
        if (folder === 'rdl') {
            filteredDocs = this.allDocuments.filter(doc => doc.processedName && doc.processedName.includes('RDL'));
        } else if (folder === 'rcs') {
            filteredDocs = this.allDocuments.filter(doc => doc.processedName && doc.processedName.includes('RCS'));
        } else if (folder === 'review') {
            filteredDocs = this.allDocuments.filter(doc => ['review', 'error'].includes(doc.status));
        }
        
        const grid = document.getElementById('documentGrid');
        if (filteredDocs.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📄</div>
                    <h3>No documents found</h3>
                    <p>No documents match the selected filter</p>
                </div>
            `;
        } else {
            grid.innerHTML = filteredDocs.map(doc => this.createDocumentCard(doc)).join('');
        }
    }
}

// Global functions
function logout() {
    localStorage.removeItem('userSession');
    window.location.href = 'index.html';
}

function closeEmailPanel() {
    document.getElementById('emailPanel').style.display = 'none';
}

function showAddClientModal() {
    alert('Add client functionality coming soon!');
}

// Add slide animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
`;
document.head.appendChild(style);

// Initialize admin dashboard
let adminDashboard;
document.addEventListener('DOMContentLoaded', () => {
    adminDashboard = new AdminDashboard();
});