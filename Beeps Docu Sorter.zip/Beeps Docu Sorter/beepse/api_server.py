#!/usr/bin/env python3
"""
Simple Flask API to connect frontend to document processor
Run this to enable real document processing from web interface
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import tempfile
from document_processor import DocumentProcessor
from email_service import EmailService

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend

# Initialize services
processor = DocumentProcessor()
email_service = EmailService()

@app.route('/api/process-document', methods=['POST'])
def process_document():
    """Process uploaded document with real email notifications"""
    
    try:
        # Get file and client info from request
        file = request.files['document']
        client_email = request.form.get('clientEmail')
        client_name = request.form.get('clientName')
        
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
            file.save(temp_file.name)
            
            # Process with real email notifications
            result = processor.process_file(
                temp_file.name, 
                client_email=client_email, 
                client_name=client_name
            )
            
            # Clean up temp file
            os.unlink(temp_file.name)
            
            return jsonify({
                'success': True,
                'result': result,
                'message': 'Document processed successfully'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'Document processing failed'
        }), 500

@app.route('/api/test-email', methods=['POST'])
def test_email():
    """Test email functionality"""
    
    try:
        success = email_service.test_email_connection()
        return jsonify({
            'success': success,
            'message': 'Email test completed'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    print("🚀 Starting Document Processing API...")
    print("📧 Make sure Gmail is configured (run setup_gmail.py)")
    print("🌐 API will run on: http://localhost:5000")
    print("🎨 Frontend should run on Live Server")
    print()
    
    app.run(debug=True, port=5000)