// Client Portal Logic 💖

class ClientPortal {
    constructor() {
        this.userSession = this.getUserSession();
        this.userDocuments = [];
        this.notifications = [];
        
        if (!this.userSession || this.userSession.role !== 'client') {
            window.location.href = 'index.html';
            return;
        }
        
        this.initializePortal();
        this.loadUserData();
    }
    
    getUserSession() {
        const session = localStorage.getItem('userSession');
        return session ? JSON.parse(session) : null;
    }
    
    initializePortal() {
        // Set welcome message
        document.getElementById('welcomeText').textContent = `Welcome, ${this.userSession.name}!`;
        
        // Initialize upload functionality
        this.initializeUpload();
        
        // Load existing documents and notifications
        this.loadDocuments();
        this.loadNotifications();
    }
    
    initializeUpload() {
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        
        // Drag and drop events
        dropZone.addEventListener('dragover', this.handleDragOver.bind(this));
        dropZone.addEventListener('dragleave', this.handleDragLeave.bind(this));
        dropZone.addEventListener('drop', this.handleDrop.bind(this));
        
        // File input change
        fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        
        // Click to upload
        dropZone.addEventListener('click', () => {
            fileInput.click();
        });
    }
    
    handleDragOver(e) {
        e.preventDefault();
        document.getElementById('dropZone').classList.add('dragover');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        document.getElementById('dropZone').classList.remove('dragover');
    }
    
    handleDrop(e) {
        e.preventDefault();
        document.getElementById('dropZone').classList.remove('dragover');
        const files = Array.from(e.dataTransfer.files);
        this.processFiles(files);
    }
    
    handleFileSelect(e) {
        const files = Array.from(e.target.files);
        this.processFiles(files);
    }
    
    async processFiles(files) {
        if (files.length === 0) return;
        
        // Show processing section
        document.getElementById('processingSection').style.display = 'block';
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            this.updateProcessingStatus(`Processing ${file.name}... (${i + 1}/${files.length})`);
            
            try {
                const result = await this.uploadAndProcessFile(file);
                this.addDocumentToList(result);
                this.addNotification('success', 'Document Uploaded', `${file.name} has been uploaded successfully`);
            } catch (error) {
                this.addNotification('error', 'Upload Failed', `Failed to upload ${file.name}: ${error.message}`);
            }
            
            await this.delay(1000);
        }
        
        // Hide processing section
        document.getElementById('processingSection').style.display = 'none';
        this.updateStats();
    }
    
    async uploadAndProcessFile(file) {
        // Simulate file upload and processing
        const documentId = 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        
        // Simulate different processing outcomes
        const outcomes = ['completed', 'processing', 'review', 'error'];
        const randomOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];
        
        // Check if password protected (simulate)
        const isPasswordProtected = file.name.toLowerCase().includes('protected');
        
        const document = {
            id: documentId,
            filename: file.name,
            originalName: file.name,
            uploadTime: new Date().toISOString(),
            status: isPasswordProtected ? 'review' : randomOutcome,
            size: this.formatFileSize(file.size),
            userEmail: this.userSession.email,
            processedName: this.generateProcessedName(file.name),
            details: this.getStatusDetails(isPasswordProtected ? 'review' : randomOutcome, isPasswordProtected)
        };
        
        // If password protected, send notification
        if (isPasswordProtected) {
            this.sendPasswordNotification(document);
        }
        
        return document;
    }
    
    generateProcessedName(filename) {
        const names = ['JOHN_SMITH', 'MARY_JOHNSON', 'DAVID_BROWN', 'SARAH_WILSON'];
        const types = ['RDL', 'RCS'];
        const randomName = names[Math.floor(Math.random() * names.length)];
        const randomType = types[Math.floor(Math.random() * types.length)];
        
        return `${randomName}_${randomType}.pdf`;
    }
    
    getStatusDetails(status, isPasswordProtected) {
        if (isPasswordProtected) {
            return 'Document is password-protected and requires resubmission';
        }
        
        const details = {
            'completed': 'Document processed successfully and filed',
            'processing': 'Document is currently being analyzed',
            'review': 'Document requires manual review',
            'error': 'Processing failed - please resubmit'
        };
        
        return details[status] || 'Status unknown';
    }
    
    sendPasswordNotification(document) {
        // Simulate sending email notification
        console.log(`📧 Email sent to ${this.userSession.email} about password-protected document: ${document.filename}`);
        
        this.addNotification('warning', 'Password-Protected Document', 
            `Your document "${document.filename}" is password-protected. Please resubmit without password protection.`);
    }
    
    addDocumentToList(document) {
        this.userDocuments.unshift(document); // Add to beginning
        this.renderDocuments();
    }
    
    loadUserData() {
        // Load user's existing documents from localStorage
        const savedDocs = localStorage.getItem(`documents_${this.userSession.email}`);
        if (savedDocs) {
            this.userDocuments = JSON.parse(savedDocs);
        }
        
        // Load notifications
        const savedNotifications = localStorage.getItem(`notifications_${this.userSession.email}`);
        if (savedNotifications) {
            this.notifications = JSON.parse(savedNotifications);
        }
        
        this.renderDocuments();
        this.renderNotifications();
        this.updateStats();
    }
    
    saveUserData() {
        localStorage.setItem(`documents_${this.userSession.email}`, JSON.stringify(this.userDocuments));
        localStorage.setItem(`notifications_${this.userSession.email}`, JSON.stringify(this.notifications));
    }
    
    loadDocuments() {
        this.renderDocuments();
    }
    
    renderDocuments() {
        const grid = document.getElementById('documentsGrid');
        
        if (this.userDocuments.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📄</div>
                    <h3>No documents uploaded yet</h3>
                    <p>Upload your first document to get started!</p>
                </div>
            `;
            return;
        }
        
        grid.innerHTML = this.userDocuments.map(doc => this.createDocumentCard(doc)).join('');
        this.saveUserData();
    }
    
    createDocumentCard(doc) {
        const statusLabels = {
            'processing': 'Processing',
            'completed': 'Completed',
            'review': 'Needs Review',
            'error': 'Error'
        };
        
        return `
            <div class="document-item ${doc.status}">
                <div class="document-header">
                    <div class="document-name">${doc.filename}</div>
                    <div class="document-status status-${doc.status}">
                        ${statusLabels[doc.status]}
                    </div>
                </div>
                <div class="document-details">
                    <strong>Uploaded:</strong> ${new Date(doc.uploadTime).toLocaleString()}<br>
                    <strong>Size:</strong> ${doc.size}<br>
                    ${doc.processedName ? `<strong>Processed as:</strong> ${doc.processedName}<br>` : ''}
                    <strong>Status:</strong> ${doc.details}
                </div>
                <div class="document-actions">
                    ${doc.status === 'completed' ? '<button class="action-btn">Download</button>' : ''}
                    ${doc.status === 'review' ? '<button class="action-btn" onclick="clientPortal.resubmitDocument(\'' + doc.id + '\')">Resubmit</button>' : ''}
                    <button class="action-btn" onclick="clientPortal.viewDetails('${doc.id}')">Details</button>
                </div>
            </div>
        `;
    }
    
    loadNotifications() {
        this.renderNotifications();
    }
    
    renderNotifications() {
        const list = document.getElementById('notificationsList');
        
        if (this.notifications.length === 0) {
            list.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">🔔</div>
                    <h3>No notifications</h3>
                    <p>You'll see updates about your documents here</p>
                </div>
            `;
            return;
        }
        
        list.innerHTML = this.notifications.slice(0, 5).map(notification => `
            <div class="notification-item ${notification.type}">
                <div class="notification-header">
                    <div class="notification-title">${notification.title}</div>
                    <div class="notification-time">${new Date(notification.time).toLocaleString()}</div>
                </div>
                <div class="notification-message">${notification.message}</div>
            </div>
        `).join('');
    }
    
    addNotification(type, title, message) {
        const notification = {
            id: Date.now(),
            type: type,
            title: title,
            message: message,
            time: new Date().toISOString()
        };
        
        this.notifications.unshift(notification);
        this.renderNotifications();
        this.saveUserData();
    }
    
    updateStats() {
        const total = this.userDocuments.length;
        const processed = this.userDocuments.filter(doc => doc.status === 'completed').length;
        const pending = this.userDocuments.filter(doc => ['processing', 'review'].includes(doc.status)).length;
        
        document.getElementById('totalUploaded').textContent = total;
        document.getElementById('processed').textContent = processed;
        document.getElementById('pending').textContent = pending;
    }
    
    updateProcessingStatus(status) {
        document.getElementById('processingStatus').textContent = status;
    }
    
    resubmitDocument(docId) {
        alert('Resubmit functionality coming soon! Please upload a new version without password protection.');
    }
    
    viewDetails(docId) {
        const doc = this.userDocuments.find(d => d.id === docId);
        if (doc) {
            alert(`Document Details:\n\nFilename: ${doc.filename}\nStatus: ${doc.details}\nUploaded: ${new Date(doc.uploadTime).toLocaleString()}`);
        }
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Logout function
function logout() {
    localStorage.removeItem('userSession');
    window.location.href = 'index.html';
}

// Initialize client portal
let clientPortal;
document.addEventListener('DOMContentLoaded', () => {
    clientPortal = new ClientPortal();
});